# Orion Player — Modern Dark Edition

A fresh Android app project named Orion Player, rebuilt from scratch using the supplied SongHub APK only as a feature reference. This is not a patch to the original binary.

## Current starter features
- Black / deep-purple Material 3 interface
- Home dashboard and song library
- Search by title, artist, or song code
- Import local audio files with Android's document picker
- Local audio playback using AndroidX Media3 / ExoPlayer
- Favorites and an in-app queue
- Mini-player and lyrics panel placeholder
- Android audio routing (Bluetooth devices work through the system's normal audio route)

## Important scope notes
The supplied APK includes substantially more functionality than can safely be reconstructed from the compiled binary alone. The original app contains karaoke/MIDI playback, MP3+MIDI chorus and multiplex modes, scoring, keypads, song reservations, background video, microphone/audio settings, and SmartLink-related UI. Those are **not implemented in this starter build yet**. MIDI playback, timed lyric parsing, scoring, external song-library scanning, and device/SmartLink protocols require a dedicated implementation and test files/hardware. The sample songs in the app are placeholders; this project does not contain the user's licensed song catalog.

## Build
Open this folder in Android Studio or a compatible AndroidIDE version with Android Gradle Plugin 8.7.3 support. Use JDK 17 and Android SDK 35. Allow Gradle to sync, then run `app`.

To make an APK: Build > Build APK(s). The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Importing music
Tap **Songs > Import** or **Home > Import music**, then select local audio files. Android's system file picker grants access to the selected files. Bluetooth playback uses the phone's current Android audio output route.

## Next engineering milestones
1. Implement original song folder/catalog format and song-code database.
2. Add timed lyrics (LRC or the original lyric format) and lyric synchronization.
3. Integrate a MIDI synthesizer and soundfont support.
4. Rebuild karaoke controls, scoring, reservation queue, and background-video modes.
5. Recreate SmartLink / remote-control functionality after documenting the protocol and target hardware.
6. Add persistent favorites, playlists, playback history, and preferences.

## Build an APK without using the AndroidIDE terminal (phone-friendly)

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a GitHub account or sign in at https://github.com.
2. Create a new repository named `Orion-Player`.
3. Upload the contents of this project folder to the repository (the folder contents, not an extra enclosing folder).
4. Open the repository's **Actions** tab and select **Build Orion Player APK**.
5. Tap **Run workflow** if it has not started automatically after upload.
6. When the run finishes successfully, open the run and download the `Orion-Player-debug-apk` artifact.

The downloaded artifact contains `app-debug.apk`. This is a debug/test APK, not a signed Play Store release. The first build may reveal source or dependency errors that need fixing.


## Latest player update
- Expanded Now Playing screen with animated decorative waveform, seek bar, elapsed time, and remaining-time countdown.
- Imported audio can be removed from the Orion Player library. This does not delete the original audio file from device storage.

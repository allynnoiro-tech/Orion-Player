package com.songhub.rebuilt

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.compose.ui.platform.LocalContext

private val Bg = Color(0xFF090711)
private val Panel = Color(0xFF171322)
private val Panel2 = Color(0xFF211A31)
private val Purple = Color(0xFF9B5CFF)
private val Pink = Color(0xFFE15BCE)
private val Muted = Color(0xFFAAA2B8)
private val White = Color(0xFFF8F5FF)

data class Song(val title: String, val artist: String, val code: String, val uri: Uri? = null, val lyrics: String = "Lyrics can be added to this song from your songbook file.")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SongHubApp() }
    }
}

@Composable
fun SongHubApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val songs = remember {
        mutableStateListOf(
            Song("Sample Song One", "Orion Player Demo", "0001"),
            Song("Midnight Memories", "Demo Artist", "0002"),
            Song("Purple Rain", "Demo Artist", "0003"),
            Song("Home Again", "Demo Artist", "0004")
        )
    }
    val favorites = remember { mutableStateListOf<String>() }
    val queue = remember { mutableStateListOf<Song>() }
    var current by remember { mutableStateOf<Song?>(null) }
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var showLyrics by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready • Choose a song or import audio") }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            val name = context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else "Imported audio"
            } ?: "Imported audio"
            val title = name.substringBeforeLast(".")
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            songs.add(Song(title, "Local audio", "LOCAL-${songs.size + 1}", uri))
        }
        status = "${uris.size} audio file(s) added to your library"
    }

    fun play(song: Song) {
        current = song
        if (song.uri != null) {
            player.setMediaItem(MediaItem.fromUri(song.uri))
            player.prepare()
            player.play()
            playing = true
            status = "Playing ${song.title}"
        } else {
            playing = false
            status = "Song selected • Add its audio/MIDI file to play"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple, secondary = Pink,
        onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF100C19), contentColor = White) {
                    listOf("Home", "Songs", "Favorites", "Queue", "Settings").forEach { item ->
                        val icon = when(item) {
                            "Home" -> Icons.Default.Home
                            "Songs" -> Icons.Default.LibraryMusic
                            "Favorites" -> Icons.Default.Favorite
                            "Queue" -> Icons.Default.QueueMusic
                            else -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(icon, null) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple, selectedTextColor = White,
                                indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                Header()
                when(tab) {
                    "Home" -> HomeScreen(songs, favorites, current, status, onBrowse = { tab = "Songs" }, onPlay = ::play, onImport = { audioPicker.launch(arrayOf("audio/*")) }, onQueue = { queue.add(it) })
                    "Songs" -> LibraryScreen(songs, query, { query = it }, favorites, onPlay = ::play, onFavorite = { s -> if (favorites.contains(s.code)) favorites.remove(s.code) else favorites.add(s.code) }, onQueue = { queue.add(it) }, onImport = { audioPicker.launch(arrayOf("audio/*")) })
                    "Favorites" -> SongListScreen("Your favorites", songs.filter { favorites.contains(it.code) }, current, ::play, { s -> if (favorites.contains(s.code)) favorites.remove(s.code) else favorites.add(s.code) }, { queue.add(it) })
                    "Queue" -> QueueScreen(queue, current, ::play, { queue.remove(it) })
                    else -> SettingsScreen(status, onImport = { audioPicker.launch(arrayOf("audio/*")) })
                }
                current?.let { song ->
                    MiniPlayer(song, playing, onToggle = {
                        if (song.uri != null) {
                            if (player.isPlaying) { player.pause(); playing = false }
                            else { player.play(); playing = true }
                        } else status = "Import an audio file to enable playback"
                    }, onLyrics = { showLyrics = true })
                }
            }
        }
        if (showLyrics && current != null) {
            AlertDialog(
                onDismissRequest = { showLyrics = false },
                containerColor = Panel,
                title = { Text(current!!.title, color = White, fontWeight = FontWeight.Bold) },
                text = { Text(current!!.lyrics, color = Muted) },
                confirmButton = { TextButton(onClick = { showLyrics = false }) { Text("Close", color = Purple) } }
            )
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Purple, Pink))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("ORION PLAYER", color = White, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("MUSIC • KARAOKE • SONGBOOK", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
        Icon(Icons.Default.Bluetooth, null, tint = Purple, modifier = Modifier.size(23.dp))
    }
}

@Composable
fun HomeScreen(songs: List<Song>, favorites: List<String>, current: Song?, status: String, onBrowse: () -> Unit, onPlay: (Song) -> Unit, onImport: () -> Unit, onQueue: (Song) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF39205D), Color(0xFF171023), Color(0xFF261238)))).padding(20.dp)) {
                Column {
                    Text("YOUR MUSIC, YOUR STAGE", color = Color(0xFFD9BFFF), fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Sing it.\nFeel it.", color = White, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Your personal songbook and music hub.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onBrowse, colors = ButtonDefaults.buttonColors(containerColor = Purple), shape = RoundedCornerShape(14.dp)) {
                        Text("Explore songbook"); Spacer(Modifier.width(6.dp)); Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("SONGS", songs.size.toString(), Icons.Default.LibraryMusic, Modifier.weight(1f))
                StatCard("FAVORITES", favorites.size.toString(), Icons.Default.Favorite, Modifier.weight(1f))
                StatCard("QUEUE", "—", Icons.Default.QueueMusic, Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quick actions", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Import music", "MP3 / audio", Icons.Default.FileUpload, onImport, Modifier.weight(1f))
                ActionCard("Browse songs", "Search library", Icons.Default.Search, onBrowse, Modifier.weight(1f))
            }
        }
        item { Text("Recently added", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(songs.takeLast(4).reversed()) { song -> SongRow(song, current?.code == song.code, false, { onPlay(song) }, { onQueue(song) }, {}) }
        item { Text(status, color = Muted, fontSize = 11.sp) }
    }
}

@Composable
fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(Panel).padding(13.dp)) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(8.dp))
        Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = .7.sp)
    }
}

@Composable
fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel2).clickable { onClick() }.padding(15.dp)) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun LibraryScreen(songs: List<Song>, query: String, onQuery: (String) -> Unit, favorites: List<String>, onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit, onQueue: (Song) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Song library", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("Find a song by title, artist or code", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search songs…", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Purple) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Panel2, focusedTextColor = White, unfocusedTextColor = White, cursorColor = Purple))
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${songs.count { it.title.contains(query, true) || it.artist.contains(query, true) || it.code.contains(query, true) }} songs", color = Muted, modifier = Modifier.weight(1f), fontSize = 12.sp)
            TextButton(onClick = onImport) { Icon(Icons.Default.Add, null, tint = Purple); Text("Import", color = Purple) }
        }
        val filtered = songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) || it.code.contains(query, true) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(filtered) { song ->
                SongRow(song, false, favorites.contains(song.code), { onPlay(song) }, { onQueue(song) }, { onFavorite(song) })
            }
        }
    }
}

@Composable
fun SongListScreen(title: String, songs: List<Song>, current: Song?, onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit, onQueue: (Song) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text(title, color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(12.dp))
        if (songs.isEmpty()) Text("No favorites yet. Tap the heart beside a song to save it here.", color = Muted, fontSize = 13.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(songs) { song -> SongRow(song, current?.code == song.code, true, { onPlay(song) }, { onQueue(song) }, { onFavorite(song) }) }
        }
    }
}

@Composable
fun SongRow(song: Song, active: Boolean, favorite: Boolean, onPlay: () -> Unit, onQueue: () -> Unit, onFavorite: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (active) Color(0xFF2A1C3B) else Panel).clickable { onPlay() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFF6D3FB2), Color(0xFF281B3B)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = White)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.artist}  •  ${song.code}", color = Muted, fontSize = 11.sp, maxLines = 1)
        }
        IconButton(onClick = onQueue) { Icon(Icons.Default.Add, "Add to queue", tint = Muted) }
        IconButton(onClick = onFavorite) { Icon(Icons.Default.Favorite, "Favorite", tint = if (favorite) Pink else Muted) }
    }
}

@Composable
fun QueueScreen(queue: List<Song>, current: Song?, onPlay: (Song) -> Unit, onRemove: (Song) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Up next", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("${queue.size} queued songs", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        if (queue.isEmpty()) Text("Your queue is empty. Add songs from the library.", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(queue) { song ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { onPlay(song) }) { Text(song.title, color = White, fontWeight = FontWeight.SemiBold); Text(song.artist, color = Muted, fontSize = 11.sp) }
                    IconButton(onClick = { onRemove(song) }) { Icon(Icons.Default.Close, null, tint = Muted) }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(status: String, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("Settings", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("Personalize your Orion Player experience.", color = Muted)
        SettingRow("Appearance", "Modern dark • black & purple", Icons.Default.Palette)
        SettingRow("Audio output", "Uses Android audio routing, including connected Bluetooth devices", Icons.Default.Bluetooth)
        SettingRow("Library", "Import local MP3 and supported audio files", Icons.Default.FolderOpen, onImport)
        SettingRow("Playback", "Audio playback powered by Android Media3", Icons.Default.Equalizer)
        SettingRow("Status", status, Icons.Default.Info)
        Text("Orion Player • 1.0.0", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable(enabled = onClick != null) { onClick?.invoke() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(13.dp))
        Column { Text(title, color = White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp) }
    }
}

@Composable
fun MiniPlayer(song: Song, playing: Boolean, onToggle: () -> Unit, onLyrics: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF21172F)).clickable { onLyrics() }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Purple), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = White) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
            Text(song.artist, color = Muted, fontSize = 10.sp)
        }
        IconButton(onClick = onLyrics) { Icon(Icons.Default.Lyrics, "Lyrics", tint = Muted) }
        IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = White) }
    }
}
